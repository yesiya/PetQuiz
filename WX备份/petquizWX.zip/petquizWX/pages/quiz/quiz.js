// pages/quiz/quiz.js
var app = getApp();//获取当前小程序实例，方便使用全局方法和属性
Page({

  //1、页面数据部分
  data: { question: "", options: "" },//设置页面数据，后面空值将在页面显示时通过请求服务器获取
  
  //2、系统事件部分
  onShow: function () {
    var that = this;
    wx.showToast({ title: '加载中', icon: 'loading', duration: 10000 })//设置加载模态框
    that.getQuiz(function (d) {
      wx.hideToast();

      var opts = [];
      for(let i = 0; i < d.options.length; ++i)
      {
        opts.push({value: d.options[i]});
      }

      that.setData({ question: d.question, options: opts})
    } );
  },
  //3、自定义页面方法：获取当前问题
  getQuiz: function (fn) {
    wx.request({//请求服务器，类似ajax
      url: 'http://127.0.0.1:8000/',
      data: {  },
      header: { 'Content-Type': 'application/json' },
      success: function (res) { fn(res.data); }//成功后将数据传给回调函数执行
    })
  },

  radioChange: function (e) {
    console.log('radio发生change事件，携带value值为：', e.detail.value)
  }



  // /**
  //  * 页面的初始数据
  //  */
  // data: {

  // },

  // /**
  //  * 生命周期函数--监听页面加载
  //  */
  // onLoad: function (options) {

  // },

  // /**
  //  * 生命周期函数--监听页面初次渲染完成
  //  */
  // onReady: function () {

  // },

  // /**
  //  * 生命周期函数--监听页面显示
  //  */
  // onShow: function () {

  // },

  // /**
  //  * 生命周期函数--监听页面隐藏
  //  */
  // onHide: function () {

  // },

  // /**
  //  * 生命周期函数--监听页面卸载
  //  */
  // onUnload: function () {

  // },

  // /**
  //  * 页面相关事件处理函数--监听用户下拉动作
  //  */
  // onPullDownRefresh: function () {

  // },

  // /**
  //  * 页面上拉触底事件的处理函数
  //  */
  // onReachBottom: function () {

  // },

  // /**
  //  * 用户点击右上角分享
  //  */
  // onShareAppMessage: function () {

  // }
})